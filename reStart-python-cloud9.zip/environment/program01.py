num1 = 5
num2 = 6
num3 = 7
avg = (num1 + num2 + num3)/3
print("avg of three number",avg)

a,b,c = input("enter the three values - ").split()
avg = (int(a)+int(b)+int(c))/3
print(avg)