vin	make	model	year	range	topSpeed	zeroSixty	mileage
TMX20122	AnyCompany Motors	Coupe	2012	335	155	4.1	50000
TM320163	AnyCompany Motors	Sedan	2016	240	140	5.2	20000
TMX20121	AnyCompany Motors	SUV	2012	295	155	4.7	100000
TMX20204	AnyCompany Motors	Truck	2020	300	155	3.5	0
