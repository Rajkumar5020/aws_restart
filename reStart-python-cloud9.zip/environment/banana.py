bananas = 1
if bananas >= 5:
    print('i have a large bunch of bananas')
elif bananas >= 1:
    print('i have a small bunch of bananas')
else:
    print('i dont have any bananas')
    